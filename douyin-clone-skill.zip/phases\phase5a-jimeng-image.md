<!-- 本文件是 douyin-clone 技能的子文件，完整流程见 ../SKILL.md -->
<!-- phase5a: 即梦AI配图（content_type=配图口播时使用） -->

## 全局上下文（必读）
- **目标**：复刻目标博主风格，制作同风格原创视频
- **风格**：读取 style_template.json（画风/配色/字幕/语气）
- **质量红线**：风格必须匹配、图≥25张、配图与文案一一对应
- **上游输出**：阶段四的 `scenes.json`（场景+提示词）、`style_template.json`
- **下游输入**：本阶段产出配图（`images/scene_XX.jpg`）供阶段六合成使用

## 5.1 AI配图（即梦无感方案 — 逆向签名算法）

**⚠️ 使用即梦网页版内部API（Fetch方式），不走官方API！**
**⚠️ 必须使用标准脚本，严禁自己写JS/API调用代码！脚本已内置sign签名算法（MD5逆向）。**

**前置条件：** openclaw浏览器中 jimeng.jianying.com 已登录。

**标准脚本：**
- 单张：`D:\video-analysis\scripts\jimeng_fetch_gen.py`
- 批量：`D:\video-analysis\scripts\jimeng_batch_fetch.py`
- 并发：`D:\video-analysis\scripts\jimeng_batch_concurrent.py`

---

### 方案A：批量脚本+browser执行（推荐）

**主会话spawn子代理时，task里这样写：**

```
步骤1：调用 jimeng_batch_fetch.py 生成所有JS文件
  chcp 65001
  python D:\video-analysis\scripts\jimeng_batch_fetch.py --input "D:\video-analysis\output\{主题}\prompts.json" --output "D:\video-analysis\output\{主题}\images" --ratio 16:9 --summary
  → 产出：images/000_generate.js, 000_poll.js, ..., summary.json

步骤2：获取即梦tab
  browser({ action: "tabs", profile: "openclaw", target: "host" })
  → 找到 jimeng.jianying.com 的 targetId

步骤3：初始化MD5签名函数
  读取 D:\video-analysis\scripts\jimeng_fetch_gen.py 中的 SIGN_JS_HELPER 变量
  browser evaluate 执行，确保 window.__jimeng_md5 可用

步骤4：逐个提交generate（读JS文件内容，browser evaluate执行）
  每个间隔2-3秒，记录返回结果

步骤5：逐个poll（读poll JS文件，browser evaluate执行）
  间隔5秒轮询，超时120秒/张
  结果中取 images[0] 的URL

步骤6：下载图片 → images/scene_XX.webp
  Invoke-WebRequest -Uri "图片URL" -OutFile "images/scene_XX.webp"
```

**并发数**：3-5个同时提交generate，然后批量轮询。超时120秒/张。
**断点续传**：跳过已存在的 scene_XX.webp。

### 方案B：串行模式（备用）

```
对每个场景：
  1. python jimeng_fetch_gen.py --action generate --prompt "xxx" --ratio "16:9" --json
  2. browser evaluate 执行返回的js
  3. 等3秒
  4. python jimeng_fetch_gen.py --action poll --submit-id "xxx" --json
  5. 间隔5秒轮询到 status=done
  6. 下载第一张图 → images/scene_XX.webp
```

**Windows编码问题解决：**
```powershell
chcp 65001
python D:\video-analysis\scripts\jimeng_fetch_gen.py ...
```

### 比例参数映射

| 比例 | image_ratio | 宽x高 |
|------|------------|--------|
| 1:1  | 1 | 2048x2048 |
| 3:4  | 3 | 1536x2048 |
| 4:3  | 4 | 2048x1536 |
| 9:16 | 5 | 1440x2560 |
| 16:9 | 6 | 2560x1440 |

**⚠️ 抖音视频一律 16:9（image_ratio=6, 2560x1440）**

### 注意事项
- 频率：生图间隔2-3秒，轮询间隔5秒，超时120秒
- 模型：`high_aes_general_v41`
- 每次生成4张图，取第一张
- 详细文档：`skills/jimeng-fetch/SKILL.md`

### 图片预览（必须步骤）
每完成5张图随机挑2-3张发给用户：
```
message({ action: "send", message: "🎨 即梦生图进度 X/Y", media: "images/scene_XX.webp" })
```
